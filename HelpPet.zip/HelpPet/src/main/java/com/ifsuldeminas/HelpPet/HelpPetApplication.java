package com.ifsuldeminas.HelpPet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpPetApplication.class, args);
	}

}
